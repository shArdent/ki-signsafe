package main

import (
	"log"
	"net/http"

	"go-ki/config"
	"go-ki/internal/auth"
	"go-ki/internal/store"

	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env found")
	}

	cfg := config.LoadConfig()

	if err := store.InitRedis(cfg.RedisAddress, cfg.RedisPassword, cfg.RedisDB); err != nil {
		log.Fatal("Failed to initialize Redis:", err)
	}

	http.HandleFunc("/api/auth", auth.AuthHandler)

	log.Printf("Server running on port %s...\n", cfg.Port)
	if err := http.ListenAndServe(":"+cfg.Port, nil); err != nil {
		log.Fatal("Server failed", err)
	}
}
