package middleware

import (
	"bytes"
	"crypto/rsa"
	"go-ki/internal/store"
	"go-ki/pkg/crypto"
	"io"
	"net/http"
	"strconv"
	"time"
)

const allowedTimeDrift = 5 * time.Minute

func AuthMiddleware(pubKey *rsa.PublicKey, next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID := r.Header.Get("X-User-ID")
		nonce := r.Header.Get("X-Nonce")
		timestampStr := r.Header.Get("X-Timestamp")
		signatureB64 := r.Header.Get("X-Signature")

		if userID == "" || nonce == "" || timestampStr == "" || signatureB64 == "" {
			http.Error(w, "Missing authentication headers", http.StatusUnauthorized)
			return
		}

		// Parse timestamp
		ts, err := parseTimestamp(timestampStr)
		if err != nil || !isTimestampValid(ts) {
			http.Error(w, "Invalid timestamp", http.StatusUnauthorized)
			return
		}

		// Cek nonce di Redis
		used, err := store.IsNonceUsed(userID, nonce)
		if err != nil || used {
			http.Error(w, "Replay attack detected", http.StatusUnauthorized)
			return
		}
		store.SaveNonce(userID, nonce, 5*time.Minute)

		// Baca payload dari body
		bodyBytes, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Failed to read body", http.StatusInternalServerError)
			return
		}
		r.Body.Close()
		r.Body = io.NopCloser(bytes.NewReader(bodyBytes))

		// Verifikasi signature
		if err := crypto.VerifySignature(pubKey, string(bodyBytes), signatureB64); err != nil {
			http.Error(w, "Invalid signature", http.StatusUnauthorized)
			return
		}

		// Signature valid, lanjutkan ke handler
		next.ServeHTTP(w, r)
	}
}

func parseTimestamp(ts string) (time.Time, error) {
	unix, err := strconv.ParseInt(ts, 10, 64)
	if err != nil {
		return time.Time{}, err
	}
	return time.Unix(unix, 0), nil
}

func isTimestampValid(ts time.Time) bool {
	now := time.Now()
	return ts.After(now.Add(-allowedTimeDrift)) && ts.Before(now.Add(allowedTimeDrift))
}
