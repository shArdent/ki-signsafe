package crypto

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
)

func Sign(hash []byte, priv *rsa.PrivateKey) ([]byte, error) {
	return rsa.SignPKCS1v15(rand.Reader, priv, crypto.SHA256, hash)
}
