package auth

type AuthRequest struct {
	UserID    string `json:"user_id"`
	Nonce     string `json:"nonce"`
	Timestamp int64  `json:"timestamp"`
	Payload   string `json:"payload"`
	Signature string `json:"signature"`
}

type AuthResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
}
