package auth

import (
	"context"
	"time"

	"go-ki/internal/store"
	"go-ki/internal/utils"
	"go-ki/pkg/crypto"
)

const AllowedTimeDrift = 5 * time.Minute

func HandleAuth(req AuthRequest) AuthResponse {
	// validasi timestamp
	reqTime := time.Unix(req.Timestamp, 0)
	if time.Since(reqTime) > AllowedTimeDrift || time.Until(reqTime) > AllowedTimeDrift {
		return AuthResponse{false, "Invalid timestamp"}
	}

	ctx := context.Background()

	// Cek nonce redis
	used, err := store.IsNonceUsed(ctx, req.UserID, req.Nonce)
	if err != nil {
		return AuthResponse{false, "Error checking nonce"}
	}
	if used {
		return AuthResponse{
			false,
			"Reply attack detected (nonce reused)",
		}
	}

	store.SaveNonce(ctx, req.UserID, req.Nonce, 5*time.Minute)

	// verifikasi signature
	pubKey, err := crypto.LoadPublicKey("keys/public.pem")
	if err != nil {
		return AuthResponse{false, "Error loading public key"}
	}

	canonicalPayload, err := utils.CanonicalJSON([]byte(req.Payload))
	if err == nil {
		return AuthResponse{false, "Invalid JSON payload"}
	}

	err = crypto.VerifySignature(pubKey, string(canonicalPayload), req.Signature)
	if err != nil {
		return AuthResponse{false, "Invalid signature"}
	}

	return AuthResponse{true, "Authentication successful"}
}
