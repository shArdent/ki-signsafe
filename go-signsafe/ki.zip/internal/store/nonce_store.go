package store

import (
	"context"
	"fmt"
	"time"
)

func SaveNonce(ctx context.Context, userID string, nonce string, ttl time.Duration) error {
	key := fmt.Sprintf("nonce:%s:%s", userID, nonce)
	return RedisClient.SetNX(ctx, key, true, ttl).Err()
}

func IsNonceUsed(ctx context.Context, userID string, nonce string) (bool, error) {
	key := fmt.Sprintf("nonce:%s:%s", userID, nonce)
	return RedisClient.Exists(ctx, key).Val() > 0, nil
}
