package utils

import (
	"bytes"
	"encoding/json"
	"sort"
)

// CanonicalJSON mengembalikan JSON string dengan key terurut secara alfabetis
func CanonicalJSON(input []byte) ([]byte, error) {
	var obj any

	if err := json.Unmarshal(input, &obj); err != nil {
		return nil, err
	}

	buf := &bytes.Buffer{}
	encoder := json.NewEncoder(buf)
	encoder.SetEscapeHTML(false)

	orderedObj := orderKeys(obj)

	if err := encoder.Encode(orderedObj); err != nil {
		return nil, err
	}

	return bytes.TrimSpace(buf.Bytes()), nil
}

func orderKeys(i any) any {
	switch v := i.(type) {
	case map[string]any:
		keys := make([]string, 0, len(v))
		for k := range v {
			keys = append(keys, k)
		}
		sort.Strings(keys)

		ordered := make(map[string]any, len(v))
		for _, k := range keys {
			ordered[k] = orderKeys(v[k])
		}
		return ordered
	case []any:
		for i := range v {
			v[i] = orderKeys(v[i])
		}
		return v
	default:
		return v
	}
}
