package config

import (
	"os"
	"strconv"
)

type Config struct {
	RedisAddress  string
	RedisPassword string
	RedisDB       int
	Port          string
}

func LoadConfig() Config {
	db, _ := strconv.Atoi(os.Getenv("REDIS_DB"))
	return Config{
		RedisAddress:  getEnv("REDIS_ADDRESS", "localhost:6379"),
		RedisPassword: getEnv("REDIS_PASSWORD", ""),
		RedisDB:       db,
		Port:          getEnv("PORT", "8000"),
	}
}

func getEnv(key string, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}
